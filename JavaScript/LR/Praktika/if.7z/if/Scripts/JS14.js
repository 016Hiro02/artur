/*
let age = Number(prompt('Введите возраст'));
if(14 >= age || 90 <= age)
{
    alert('Да');
}
else
{
    alert('нет');
}
*/
let age =prompt('введите ваш возраст');
if(!(14 < age) || !(90 > age))
{
    alert('да');
}
else
{
    alert('нет');
}