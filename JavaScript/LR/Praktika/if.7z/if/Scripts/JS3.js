vop = Number(prompt('Введите число'));
if (vop > 0)
{
    alert('1');
}
else if (vop < 0)
{   alert('-1');

}
else if (vop == 0)
{
    alert('0');
}
else
{
    alert('Не число')
}