vop = prompt('Какое офицальное название JavaScript?')
if (vop == 'ECMAScript')
{
    alert('Правильно!');
}
else
{
    alert('Не знаете? \n\"ECMAScript!\"');
}