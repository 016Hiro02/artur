let age = Number(prompt('Введите возраст'));
if(14 <= age && 90 >= age)
{
    alert('Да');
}
else
{
    alert('нет');
}