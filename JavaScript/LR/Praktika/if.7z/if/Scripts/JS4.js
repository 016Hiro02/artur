let result;
a = Number(prompt('Введите a'));
b = Number(prompt('Введите b'));
(a+b < 4) ? result ='мало': result ='Много';
alert(result);