//alert(null ||2||undefined)
//alert( alert(1) || 2 || alert(3) )
alert( 1 && null && 2 )
