let result;
x = Number(prompt('Введите x'));
y = Number(prompt('Введите y'));
(x > y)? result= "x больше, чем y":result= "x не больше, чем y";
alert(result);