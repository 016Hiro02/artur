num = Number(prompt('Введите число'));
if (num%2==0)
{
    alert('Число '+num+' Четное');
}
else if (num%2!=0)
{
    alert('Число '+num+' Нечетное');
}