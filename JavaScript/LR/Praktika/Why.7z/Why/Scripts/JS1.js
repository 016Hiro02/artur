let i = 3;

while (i)
{
    alert( i--);
}