/*
let i = 0;

while (++i < 5)
{
    alert(i);
}
*/
let i = 0;

while (i++ < 5)
{
    alert(i);
}