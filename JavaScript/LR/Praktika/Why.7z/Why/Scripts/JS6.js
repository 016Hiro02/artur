let num
do
{
    num = Number(prompt('Введите число'));
}
while(num <= 100&&num !=''&&num!=null)
