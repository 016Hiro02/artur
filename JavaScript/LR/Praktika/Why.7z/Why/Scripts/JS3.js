/*
for(let i = 0; i < 5; i++)
{
    alert(i);
}
*/
for(let i = 0; i < 5; ++i)
{
    alert(i);
}